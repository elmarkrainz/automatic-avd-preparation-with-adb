                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2731982
Snovflake by Ardu_Pol is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

This is my first work at BlocksCAD. The design of the snowflake was invented by me. Subsequent processing of snowflakes is not necessary

# Print Settings

Printer Brand: Prusa
Printer: Prusa Clone
Rafts: Doesn't Matter
Supports: No
Resolution: 2mm layer high
Infill: 50%

# Post-Printing

## Step 1

First, you can slightly polish the surface of snowflakes. I sanded it with P400 sandpaper. The surface should be slightly opaque.

![Alt text](https://cdn.thingiverse.com/assets/4c/b1/a3/2a/a2/IMG_0672.JPG)

![Alt text](https://cdn.thingiverse.com/assets/bc/93/02/19/5a/IMG_0674.JPG)

## Step 2 (not necessary)

After polishing the model should be covered with acrylic filler. The best acrylic filler is gray. Apply preferably in 2 - 3 layers, with an exposure of 2 - 3 minutes

![Alt text](https://cdn.thingiverse.com/assets/5f/ef/00/e8/fe/IMG_0675.JPG)

## Step 3

After the priming (or immediately after grinding) you can draw snowflakes, I used an aryl enamel of gold color. If you apply soil, the enamel can be used in any composition.

![Alt text](https://cdn.thingiverse.com/assets/15/4d/a7/37/d3/IMG_0676.JPG)

## At the end

After working on a snowflake, you can hang it on a chandelier in your room or somewhere else ...
Thank you for attention!

![Alt text](https://cdn.thingiverse.com/assets/bc/62/93/b3/d2/IMG_0679.JPG)